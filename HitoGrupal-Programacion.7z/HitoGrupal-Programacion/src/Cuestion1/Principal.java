package Cuestion1;

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;

public class Principal {
	public static void main(String[] args) throws FileNotFoundException {
		Empleado miEmpleado = new Empleado("Jose",25,"Calle Madrid", "66666662", "Juan", 0);
		System.out.println(miEmpleado.toString());
		miEmpleado.andar(); // Acelerar 10 km/hora.
		miEmpleado.andar(25); // Acelera 25 km/hora.
		
		File fichero = new File("productos.txt");
		Scanner lector = new Scanner(fichero);
		while (lector.hasNext() == true ) {    
		String prod1 = lector.nextLine();
		System.out.println("ID Producto: " + prod1);
		String prod2 = lector.nextLine();
		System.out.println("Nombre: " + prod2);
		String prod3 = lector.nextLine();
		System.out.println("Categoria: " + prod3);
		String prod4 = lector.nextLine();
		System.out.println("Precio: " + prod4);
		String prod5 = lector.nextLine();
		System.out.println("Stock: " + prod5);
		System.out.println("--------FIN DEL TEST----------");
		
		  }
		lector.close();
	}

}