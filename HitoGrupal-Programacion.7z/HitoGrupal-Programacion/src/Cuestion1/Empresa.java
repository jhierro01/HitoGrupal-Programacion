package Cuestion1;

	public class Empresa {
		  private String nombre;
		  private String cif;
		  private String direcci�n;
		  private Empleado empleado;
		  
		  public Empleado getEmpleado() {
				return empleado;
			}
			public void setEmpleado(Empleado empleado) {
				this.empleado = empleado;
			}
		  
		  
		  public String getNombre() {
			    return nombre;
			  }
			  public void setNombre(String nombre) {
			    this.nombre = nombre;
			  }

		  public String getDirecci�n() {
		    return direcci�n;
		  }
		  public void setDirecci�n(String direcci�n) {
		    this.direcci�n = direcci�n;
		  }
		  public String getCif() {
		    return cif;
		  }
		  public void setCif(String cif) {
		    this.cif = cif;
		  }
		
		  
		
}
