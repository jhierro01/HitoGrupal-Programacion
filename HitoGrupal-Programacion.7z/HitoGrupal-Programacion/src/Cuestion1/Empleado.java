package Cuestion1;

public class Empleado extends Persona {
	  private String nombre;
	  private String apellido;
	  private String telefono;
	  private int distancia;
	  
	public Empleado(String nombre, int edad, String direcci�n, String telefono, String apellido, int distancia) {
		super(nombre, edad, direcci�n);
		this.nombre = nombre;
		this.apellido = apellido;
		this.telefono = telefono;
		this.distancia = distancia;
	}
	
	public void andar(int cuanto) {
		this.distancia = this.distancia + cuanto;
		}
		public void andar() {
			this.distancia = this.distancia + 10;
		}

	public int getDistancia() {
			return distancia;
		}

		public void setDistancia(int distancia) {
			this.distancia = distancia;
		}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	
	
	
}
