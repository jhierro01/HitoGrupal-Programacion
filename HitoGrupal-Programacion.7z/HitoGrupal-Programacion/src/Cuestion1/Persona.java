package Cuestion1;

public class Persona {
		  private String nombre;
		  private int edad;
		  private String direcci�n;
		  
		  public Persona(String nombre, int edad, String direcci�n) {
		    super();
		    this.nombre = nombre;
		    this.edad = edad;
		    this.direcci�n = direcci�n;
		  }

		  public String getNombre() {
		    return nombre;
		  }
		  public void setNombre(String nombre) {
		    this.nombre = nombre;
		  }
		  public int getEdad() {
		    return edad;
		  }
		  public void setEdad(int edad) {
		    this.edad = edad;
		  }

		public String getDirecci�n() {
			return direcci�n;
		}

		public void setDirecci�n(String direcci�n) {
			this.direcci�n = direcci�n;
		}
		  
		  
		}

